/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anusha
 */

import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.SQLException;
import java.sql.Statement;

public class connection {

    public Connection connect() throws SQLException {
        String url = "jdbc:postgresql://localhost:5432/school";
        String username = "postgres";
        String password = "1234";

        Connection conn;

        conn = DriverManager.getConnection(url, username, password );

        System.out.println("You are successfully connected to the PostgreSQL database server.");
        Statement stmt = conn.createStatement();
        //String q = "CREATE TABLE IF NOT EXISTS student ( id int NOT NULL PRIMARY KEY, name varchar(30) NOT NULL, mother varchar(30) NOT NULL, father varchar(30) NOT NULL, gender varchar(30) NOT NULL, class NOT NULL, dob varchar(30) NOT NULL,sec vachar(3))";
        String q = "Create Table Test(id int primary key,name varchar, address text)";
        stmt.executeUpdate(q);
        System.out.println("Created table");
        stmt.close();
            //stmt.executeUpdate("CREATE TABLE IF NOT EXISTS teacher( id int(11) NOT NULL PRIMARY KEY, name varchar(30) NOT NULL, gender varchar(30) NOT NULL,subject varchar(30) NOT NULL);");
            //stmt.executeUpdate("CREATE TABLE IF NOT EXISTS staff ( id int(11) NOT NULL PRIMARY KEY, name varchar(30) NOT NULL, designation varchar(30) NOT NULL, gender varchar(30) NOT NULL);");
            //stmt.executeUpdate("CREATE TABLE IF NOT EXISTS ids ( id int(5), flag int(1) );");
            //stmt.executeUpdate("CREATE TABLE IF NOT EXISTS cid ( id int(5), flag int(1) );");
            //stmt.executeUpdate("CREATE TABLE IF NOT EXISTS attendance ( id int(5),  maths_att int(3), phy_att int(3), chem_att int(3), );");


        return conn;
}
     public static void main(String[] args) throws SQLException 

    {

       connection conn = new connection();

       conn.connect();

    }

}
