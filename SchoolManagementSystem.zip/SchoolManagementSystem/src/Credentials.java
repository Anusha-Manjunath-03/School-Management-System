/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anusha
 */
public class Credentials {
    public static String[] adminUserNames={"admin1","admin2","admin3"};
    public static String[] adminPassword={"1234","5678","string"};
    public static String[] teacherUserNames={"teacher1","teacher2","teacher3"};
    public static String[] teacherPassword={"1234","5678","string"};
    public static String[] studentUserNames={"student1","student2","student3"};
    public static String[] studentPassword={"1234","5678","string"};
    public static String[] staffUserNames={"staff1","staff2","staff3"};
    public static String[] staffPassword={"1234","5678","string"};
    public static String sqlPassword = "1234";
}
